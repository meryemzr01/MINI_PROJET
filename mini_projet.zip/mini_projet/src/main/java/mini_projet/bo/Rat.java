package mini_projet.bo;

public class Rat extends Animal {

    public Rat(int x, int y, Joueur proprietaire) {
        super("Rat", 1, x, y, proprietaire);
    }

    @Override
    public boolean peutCapturer(Animal cible, Cellule[][] plateau) {
        if (cible == null || cible.getProprietaire() == this.proprietaire) return false;

        CelluleType maCellule = plateau[x][y].getType();
        CelluleType celluleCible = plateau[cible.getX()][cible.getY()].getType();

        //  Interdiction de capturer entre eau et terre
        if ((maCellule == CelluleType.RIVIERE) != (celluleCible == CelluleType.RIVIERE)) return false;

        //  Peut capturer l’Éléphant
        if (cible.getNom().equalsIgnoreCase("Éléphant")) return true;

        //  Capture normale par force
        return this.force >= cible.getForce();
    }

    @Override
    public boolean peutSeDeplacerVers(int newX, int newY, Cellule[][] plateau) {
        int dx = Math.abs(newX - x);
        int dy = Math.abs(newY - y);

        // Peut se déplacer dans l’eau et sur terre (orthogonalement)
        return (dx + dy == 1);
    }

    @Override
    public char getSymbole() {
        return 'R';
    }
}
