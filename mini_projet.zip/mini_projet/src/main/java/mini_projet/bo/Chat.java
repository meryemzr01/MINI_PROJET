package mini_projet.bo;

public class Chat extends Animal {

    public Chat(int x, int y, Joueur proprietaire) {
        super("Chat", 2, x, y, proprietaire);
    }

    @Override
    public boolean peutCapturer(Animal cible, Cellule[][] plateau) {
        return cible != null &&
               cible.getProprietaire() != this.proprietaire &&
               this.force >= cible.getForce();
    }

    @Override
    public boolean peutSeDeplacerVers(int newX, int newY, Cellule[][] plateau) {
        int dx = Math.abs(newX - x);
        int dy = Math.abs(newY - y);

        if (dx + dy != 1) return false;

        // Le chat ne peut pas marcher sur l'eau 
        return plateau[newX][newY].getType() != CelluleType.RIVIERE;
    }

    @Override
    public char getSymbole() {
        return 'C';
    }
}
