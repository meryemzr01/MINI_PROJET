package mini_projet.bo;

public class Loup extends Animal {

    public Loup(int x, int y, Joueur proprietaire) {
        super("Loup", 4, x, y, proprietaire);
    }

    @Override
    public boolean peutCapturer(Animal cible, Cellule[][] plateau) {
        return cible != null &&
               cible.getProprietaire() != this.proprietaire &&
               this.force >= cible.getForce();
    }

    @Override
    public boolean peutSeDeplacerVers(int newX, int newY, Cellule[][] plateau) {
        int dx = Math.abs(newX - x);
        int dy = Math.abs(newY - y);

       
        return (dx + dy == 1) &&
               plateau[newX][newY].getType() != CelluleType.RIVIERE;
    }

    @Override
    public char getSymbole() {
        return 'W'; // 'W' pour "Wolf"
    }

    @Override
    public boolean peutCapturer(Animal cible) {
        return peutCapturer(cible, null);
    }
}
