package mini_projet.bo;

public class Cellule {

    private CelluleType type;
    private Animal occupant;

    public Cellule(CelluleType type) {
        this.type = type;
    }

    public boolean estLibre() {
        return occupant == null;
    }

    public CelluleType getType() {
        return type;
    }

    public void setType(CelluleType type) {
        this.type = type;
    }

    public Animal getOccupant() {
        return occupant;
    }

    public void setOccupant(Animal occupant) {
        this.occupant = occupant;
    }
}
