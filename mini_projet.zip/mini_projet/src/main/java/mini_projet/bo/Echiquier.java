package mini_projet.bo;

public class Echiquier {

    private final int NB_LIGNES = 9;
    private final int NB_COLONNES = 7;
    private Cellule[][] plateau;

    public Echiquier() {
        plateau = new Cellule[NB_LIGNES][NB_COLONNES];
        initialiserPlateau();
    }

    private void initialiserPlateau() {
        // 1. Par défaut, tout est NORMAL
        for (int i = 0; i < NB_LIGNES; i++) {
            for (int j = 0; j < NB_COLONNES; j++) {
                plateau[i][j] = new Cellule(CelluleType.NORMAL);
            }
        }

        // 2. Zones spéciales : rivières (zones centrales)
        int[][] riviere = {
            {3,1},{3,2},{4,1},{4,2},{5,1},{5,2},
            {3,4},{3,5},{4,4},{4,5},{5,4},{5,5}
        };
        for (int[] pos : riviere) {
            plateau[pos[0]][pos[1]].setType(CelluleType.RIVIERE);
        }

        // 3. Pièges joueur 1
        plateau[0][2].setType(CelluleType.PIEGE);
        plateau[0][4].setType(CelluleType.PIEGE);
        plateau[1][3].setType(CelluleType.PIEGE);

        // 4. Terrier joueur 1
        plateau[0][3].setType(CelluleType.TERRIER);

        // 5. Pièges joueur 2
        plateau[8][2].setType(CelluleType.PIEGE);
        plateau[8][4].setType(CelluleType.PIEGE);
        plateau[7][3].setType(CelluleType.PIEGE);

        // 6. Terrier joueur 2
        plateau[8][3].setType(CelluleType.TERRIER);
    }

    public Cellule getCellule(int x, int y) {
        return plateau[x][y];
    }

    public void setCellule(int x, int y, Cellule cellule) {
        plateau[x][y] = cellule;
    }
    public Cellule[][] getPlateau() {
        return plateau;
    }

    public void afficherPlateau() {
        System.out.println("\n    0  1  2  3  4  5  6");
        System.out.println("   ---------------------");

        for (int i = 0; i < 9; i++) {
            System.out.print(i + " | ");
            for (int j = 0; j < 7; j++) {
                Cellule cell = plateau[i][j];
                Animal occupant = cell.getOccupant();

                // Affichage des animaux 
                if (occupant != null) {
                    char symbole = occupant.getSymbole(); 
                    if (occupant.getProprietaire().getId() == 1) {
                        System.out.print(symbole + "↑ ");
                    } else {
                        System.out.print(symbole + "↓ ");
                    }
                } else {
                    switch (cell.getType()) {
                        case RIVIERE -> System.out.print("~  ");
                        case TERRIER -> System.out.print("T  ");
                        case PIEGE -> System.out.print("X  ");
                        default -> System.out.print(".  ");
                    }
                }
            }
            System.out.println();
        }
        System.out.println("   ---------------------");
    }

    }


