package mini_projet.bo;

public enum CelluleType {
    NORMAL, RIVIERE, PIEGE, TERRIER
}
