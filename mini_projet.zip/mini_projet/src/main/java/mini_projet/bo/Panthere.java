package mini_projet.bo;

public class Panthere extends Animal {

    public Panthere(int x, int y, Joueur proprietaire) {
        super("Panthère", 5, x, y, proprietaire);
    }

    @Override
    public boolean peutCapturer(Animal cible, Cellule[][] plateau) {
        return cible != null &&
               cible.getProprietaire() != this.proprietaire &&
               this.force >= cible.getForce();
    }

    @Override
    public boolean peutSeDeplacerVers(int newX, int newY, Cellule[][] plateau) {
        int dx = Math.abs(newX - x);
        int dy = Math.abs(newY - y);

        // Déplacement d'une seule case 
        return (dx + dy == 1) &&
               plateau[newX][newY].getType() != CelluleType.RIVIERE;
    }

    @Override
    public char getSymbole() {
        return 'P';
    }

    @Override
    public boolean peutCapturer(Animal cible) {
        return peutCapturer(cible, null);
    }
}
