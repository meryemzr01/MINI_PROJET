package mini_projet.bo;

public class Tigre extends Animal {

    public Tigre(int x, int y, Joueur proprietaire) {
        super("Tigre", 6, x, y, proprietaire);
    }

    @Override
    public boolean peutSeDeplacerVers(int newX, int newY, Cellule[][] plateau) {
        int dx = Math.abs(newX - x);
        int dy = Math.abs(newY - y);

        // Déplacement normal d'une case
        if (dx + dy == 1) {
            return plateau[newX][newY].getType() != CelluleType.RIVIERE;
        }

        // Tigre peut sauter la riviere 
        return peutSauterParDessusRiviere(x, y, newX, newY, plateau);
    }

    @Override
    public boolean peutCapturer(Animal cible, Cellule[][] plateau) {
        return cible != null &&
               cible.getProprietaire() != this.proprietaire &&
               this.force >= cible.getForce();
    }

    @Override
    public char getSymbole() {
        return 'T';
    }

    private boolean peutSauterParDessusRiviere(int startX, int startY, int endX, int endY, Cellule[][] plateau) {
        // Saut horizontal
        if (startX == endX) {
            int step = (endY > startY) ? 1 : -1;
            for (int y = startY + step; y != endY; y += step) {
                Cellule cell = plateau[startX][y];
                if (cell.getType() != CelluleType.RIVIERE) return false;
                if (cell.getOccupant() != null && "Rat".equals(cell.getOccupant().getNom())) return false;
            }
        }
        // Saut vertical
        else if (startY == endY) {
            int step = (endX > startX) ? 1 : -1;
            for (int x = startX + step; x != endX; x += step) {
                Cellule cell = plateau[x][startY];
                if (cell.getType() != CelluleType.RIVIERE) return false;
                if (cell.getOccupant() != null && "Rat".equals(cell.getOccupant().getNom())) return false;
            }
        } else {
           
            return false;
        }

        // Ne peut pas marcher sur l'eau 
        return plateau[endX][endY].getType() != CelluleType.RIVIERE;
    }
}
