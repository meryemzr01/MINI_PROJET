package mini_projet.bo;

public abstract class Animal {

    protected String nom;
    protected int force;
    protected int x;
    protected int y;
    protected Joueur proprietaire;

    public Animal(String nom, int force, int x, int y, Joueur proprietaire) {
        this.nom = nom;
        this.force = force;
        this.x = x;
        this.y = y;
        this.proprietaire = proprietaire;
    }

    public abstract boolean peutCapturer(Animal cible, Cellule[][] plateau);

    public abstract boolean peutSeDeplacerVers(int newX, int newY, Cellule[][] plateau);

    public String getNom() { return nom; }
    public int getForce() { return force; }
    public int getX() { return x; }
    public int getY() { return y; }
    public Joueur getProprietaire() { return proprietaire; }

    public void setPosition(int x, int y) {
        this.x = x;
        this.y = y;
    }

    public abstract char getSymbole();

	public boolean peutCapturer(Animal cible) {
		// TODO Auto-generated method stub
		return false;
	}
}
