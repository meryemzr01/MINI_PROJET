package mini_projet.bo;

import java.time.LocalDateTime;

public class Partie {

    private Long id;
    private Joueur joueur1;
    private Joueur joueur2;
    private Joueur gagnant; //  null en cas d'égalité
    private LocalDateTime datePartie;

    public Partie() {}

    public Partie(Long id, Joueur joueur1, Joueur joueur2, Joueur gagnant, LocalDateTime datePartie) {
        this.id = id;
        this.joueur1 = joueur1;
        this.joueur2 = joueur2;
        this.gagnant = gagnant;
        this.datePartie = datePartie;
    }

    // Getters & Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public Joueur getJoueur1() { return joueur1; }
    public void setJoueur1(Joueur joueur1) { this.joueur1 = joueur1; }

    public Joueur getJoueur2() { return joueur2; }
    public void setJoueur2(Joueur joueur2) { this.joueur2 = joueur2; }

    public Joueur getGagnant() { return gagnant; }
    public void setGagnant(Joueur gagnant) { this.gagnant = gagnant; }

    public LocalDateTime getDatePartie() { return datePartie; }
    public void setDatePartie(LocalDateTime datePartie) { this.datePartie = datePartie; }

    @Override
    public String toString() {
        return "Partie{" +
                "id=" + id +
                ", joueur1=" + (joueur1 != null ? joueur1.getUsername() : "N/A") +
                ", joueur2=" + (joueur2 != null ? joueur2.getUsername() : "N/A") +
                ", gagnant=" + (gagnant != null ? gagnant.getUsername() : "Égalité") +
                ", date=" + datePartie +
                '}';
    }
}
