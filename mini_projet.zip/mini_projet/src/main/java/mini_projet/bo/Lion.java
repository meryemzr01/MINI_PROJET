package mini_projet.bo;

public class Lion extends Animal {

    public Lion(int x, int y, Joueur proprietaire) {
        super("Lion", 7, x, y, proprietaire);
    }

    @Override
    public boolean peutSeDeplacerVers(int newX, int newY, Cellule[][] plateau) {
        int dx = Math.abs(newX - x);
        int dy = Math.abs(newY - y);

        // Déplacement normal 
        if (dx + dy == 1) {
            return plateau[newX][newY].getType() != CelluleType.RIVIERE;
        }

        // lion peut sauter la rivière 
        return peutSauterParDessusRiviere(x, y, newX, newY, plateau);
    }

    @Override
    public boolean peutCapturer(Animal cible, Cellule[][] plateau) {
        return cible != null &&
               cible.getProprietaire() != this.proprietaire &&
               this.force >= cible.getForce();
    }

    @Override
    public char getSymbole() {
        return 'L';
    }

    private boolean peutSauterParDessusRiviere(int startX, int startY, int endX, int endY, Cellule[][] plateau) {
        // Saut horizontal
        if (startX == endX) {
            int step = (endY > startY) ? 1 : -1;
            for (int y = startY + step; y != endY; y += step) {
                Cellule cell = plateau[startX][y];
                if (cell.getType() != CelluleType.RIVIERE) return false;
                if (cell.getOccupant() != null && "Rat".equals(cell.getOccupant().getNom())) return false;
            }
        }
        // Saut vertical
        else if (startY == endY) {
            int step = (endX > startX) ? 1 : -1;
            for (int x = startX + step; x != endX; x += step) {
                Cellule cell = plateau[x][startY];
                if (cell.getType() != CelluleType.RIVIERE) return false;
                if (cell.getOccupant() != null && "Rat".equals(cell.getOccupant().getNom())) return false;
            }
        } else {
            return false;
        }

        // Ne pas marcher sur la rivière 
        return plateau[endX][endY].getType() != CelluleType.RIVIERE;
    }
}
