package mini_projet.bll;

import mini_projet.bo.*;

import java.util.ArrayList;
import java.util.List;

public class GameManager {

    private Joueur joueur1;
    private Joueur joueur2;
    private Joueur joueurActuel;
    private Echiquier echiquier;
    private List<Animal> pieces;

    public GameManager(Joueur j1, Joueur j2) {
        this.joueur1 = j1;
        this.joueur2 = j2;
        this.joueurActuel = j1;
        this.echiquier = new Echiquier();
        initialiserAnimaux();
    }

    private void initialiserAnimaux() {
        pieces = new ArrayList<>(List.of(
            // Joueur 1
            new Rat(2, 0, joueur1),
            new Chat(1, 5, joueur1),
            new Chien(1, 1, joueur1),
            new Loup(2, 2, joueur1),
            new Panthere(2, 4, joueur1),
            new Tigre(0, 6, joueur1),
            new Lion(0, 0, joueur1),
            new Elephant(2, 6, joueur1),

            // Joueur 2
            new Rat(6, 6, joueur2),
            new Chat(7, 1, joueur2),
            new Chien(7, 5, joueur2),
            new Loup(6, 4, joueur2),
            new Panthere(6, 2, joueur2),
            new Tigre(8, 0, joueur2),
            new Lion(8, 6, joueur2),
            new Elephant(6, 0, joueur2)
        ));

        for (Animal a : pieces) {
            echiquier.getCellule(a.getX(), a.getY()).setOccupant(a);
        }
    }

    public void afficherPlateau() {
        echiquier.afficherPlateau();
    }

    public boolean deplacerAnimal(Animal animal, int newX, int newY) {
        if (animal.getProprietaire() != joueurActuel) {
            System.out.println("***Ce n'est pas ton tour*** ");
            return false;
        }

        if (!animal.peutSeDeplacerVers(newX, newY, echiquier.getPlateau())) {
            System.out.println("----Déplacement non autorisé----");
            return false;
        }

        Cellule source = echiquier.getCellule(animal.getX(), animal.getY());
        Cellule cible = echiquier.getCellule(newX, newY);
        Animal cibleAnimal = cible.getOccupant();

        // Le Rat ne peut pas capturer en sortant de la rivière
        if (animal instanceof Rat &&
            source.getType() == CelluleType.RIVIERE &&
            cible.getType() != CelluleType.RIVIERE &&
            cibleAnimal != null) {
            System.out.println("***Le Rat ne peut pas capturer en sortant de la rivière***");
            return false;
        }

        // Entrée interdite dans son propre terrier
        if (cible.getType() == CelluleType.TERRIER) {
            if ((joueurActuel == joueur1 && newX == 0 && newY == 3) ||
                (joueurActuel == joueur2 && newX == 8 && newY == 3)) {
                System.out.println("***Vous ne pouvez pas entrer dans votre propre terrier*** ");
                return false;
            }
        }

     
        if (cibleAnimal != null) {
            int forceAttaquant = animal.getForce();
            int forceCible = cibleAnimal.getForce();

            // un animal sur un piège a une force de 0
            
            if (source.getType() == CelluleType.PIEGE) forceAttaquant = 0;
            if (echiquier.getCellule(cibleAnimal.getX(), cibleAnimal.getY()).getType() == CelluleType.PIEGE)
                forceCible = 0;

            boolean peutCapturer = animal.peutCapturer(cibleAnimal, echiquier.getPlateau()) || forceAttaquant >= forceCible;

            if (!peutCapturer) {
                System.out.println("***Capture non autorisée selon force insuffisante***");
                return false;
            }

            pieces.remove(cibleAnimal);
            System.out.println("----Capture réussie!----");
        }

      
        echiquier.getCellule(animal.getX(), animal.getY()).setOccupant(null);
        cible.setOccupant(animal);
        animal.setPosition(newX, newY);

        //  Condition de victoire
        if (cible.getType() == CelluleType.TERRIER && cibleAnimal == null) {
            System.out.println("----Le joueur " + joueurActuel.getUsername() + " a gagné !----");
            return true;
        }

        changerTour();
        return true;
    }

    private void changerTour() {
        joueurActuel = (joueurActuel == joueur1) ? joueur2 : joueur1;
    }

    public Joueur getJoueurActuel() {
        return joueurActuel;
    }

    public List<Animal> getPieces() {
        return pieces;
    }

    public Echiquier getEchiquier() {
        return echiquier;
    }
}
