package mini_projet.dal;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtils {

    // Configuration de la bdd
    private static final String URL = "jdbc:h2:~/mini_projet/.data";
    private static final String USER = "sa";
    private static final String PASSWORD = "";
    private static final String DRIVER_NAME = "org.h2.Driver";

    // Connexion unique
    private static Connection con;

    // Constructeur privé 
    private DBUtils() {
        try {
            Class.forName(DRIVER_NAME); // Charger le driver H2
            con = DriverManager.getConnection(URL, USER, PASSWORD);
        } catch (ClassNotFoundException e) {
            throw new DBexception("Pilote JDBC introuvable", e);
        } catch (SQLException e) {
            throw new DBexception("Erreur de connexion à la base H2", e);
        }
    }

    //Fournit une connexion à la base 
    
    public static Connection getConnection() {
        try {
            if (con == null || con.isClosed() || !con.isValid(2)) {
                new DBUtils(); 
            }
        } catch (SQLException e) {
            throw new DBexception("Échec de récupération de la connexion", e);
        }
        return con;
    }

    
    public static void safelyResetAutoCommit() {
        try {
            if (con != null && !con.getAutoCommit()) {
                con.setAutoCommit(true);
            }
        } catch (SQLException ex) {
            safelyCloseConnection();
            System.exit(-1);
        }
    }

    //Ferme proprement la connexion si elle est encore ouverte.
  
    public static void safelyCloseConnection() {
        try {
            if (con != null && !con.isClosed()) {
                con.close();
            }
        } catch (SQLException ex) {
            System.err.println("Erreur lors de la fermeture de la connexion.");
        }
    }
}
