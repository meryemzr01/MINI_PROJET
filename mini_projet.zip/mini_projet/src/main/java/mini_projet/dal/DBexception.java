package mini_projet.dal;

// Exception personnalisée pour les erreurs liées à la base de données.

public class DBexception extends RuntimeException {

    public DBexception(String message, Throwable cause) {
        super(message, cause);
    }

    public DBexception(String message) {
        super(message);
    }

    public DBexception(Throwable cause) {
        super(cause);
    }
}
