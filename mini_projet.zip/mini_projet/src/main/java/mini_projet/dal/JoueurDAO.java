package mini_projet.dal;

import mini_projet.bo.Joueur;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class JoueurDAO {

    // Ajoute un nouveau joueur à la bdd
     
    public void ajouterJoueur(Joueur joueur) {
        String sql = "INSERT INTO JOUEUR (username, password, email) VALUES (?, ?, ?)";

        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setString(1, joueur.getUsername());
            ps.setString(2, joueur.getPassword());
            ps.setString(3, joueur.getEmail());
            ps.executeUpdate();

            // Récupération de l'ID généré automatiquement
            ResultSet rs = ps.getGeneratedKeys();
            if (rs.next()) {
                joueur.setId(rs.getLong(1));
            }

        } catch (SQLException e) {
            throw new DBexception("Erreur lors de l'ajout du joueur", e);
        }
    }

    // Recherche un joueur par son nom d'utilisateur.
    
    public Joueur getJoueurParUsername(String username) {
        String sql = "SELECT * FROM JOUEUR WHERE username = ?";

        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return construireJoueur(rs);
            }

        } catch (SQLException e) {
            throw new DBexception("Erreur lors de la récupération du joueur", e);
        }

        return null;
    }

    // Récupère tous les joueurs.
    
    public List<Joueur> listerTousLesJoueurs() {
        List<Joueur> joueurs = new ArrayList<>();
        String sql = "SELECT * FROM JOUEUR";

        try (Connection con = DBUtils.getConnection();
             Statement stmt = con.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {

            while (rs.next()) {
                joueurs.add(construireJoueur(rs));
            }

        } catch (SQLException e) {
            throw new DBexception("Erreur lors du chargement des joueurs", e);
        }

        return joueurs;
    }

    // Authentifie un joueur par username + mot de passe.
     
    public Joueur authentifier(String username, String password) {
        String sql = "SELECT * FROM JOUEUR WHERE username = ? AND password = ?";

        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return construireJoueur(rs);
            }

        } catch (SQLException e) {
            throw new DBexception("Erreur lors de l'authentification", e);
        }

        return null;
    }

    // Recherche un joueur par son ID.
   
    public Joueur getJoueurParId(Long id) {
        String sql = "SELECT * FROM JOUEUR WHERE id = ?";

        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {

            ps.setLong(1, id);
            ResultSet rs = ps.executeQuery();

            if (rs.next()) {
                return construireJoueur(rs);
            }

        } catch (SQLException e) {
            throw new DBexception("Erreur lors de la récupération du joueur par ID", e);
        }

        return null;
    }

    private Joueur construireJoueur(ResultSet rs) throws SQLException {
        return new Joueur(
            rs.getLong("id"),
            rs.getString("username"),
            rs.getString("password"),
            rs.getString("email")
        );
    }
}
