package mini_projet.dal;

import mini_projet.bo.Joueur;
import mini_projet.bo.Partie;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class PartieDAO {

    public void ajouterPartie(Partie partie) {
        String sql = """
            INSERT INTO PARTIE (joueur1Id, joueur2Id, gagnantId, date)
            VALUES (?, ?, ?, ?)
        """;

        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql, Statement.RETURN_GENERATED_KEYS)) {

            ps.setLong(1, partie.getJoueur1().getId());
            ps.setLong(2, partie.getJoueur2().getId());
            if (partie.getGagnant() != null) {
                ps.setLong(3, partie.getGagnant().getId());
            } else {
                ps.setNull(3, Types.BIGINT);
            }
            ps.setTimestamp(4, Timestamp.valueOf(partie.getDatePartie()));
            ps.executeUpdate();

            try (ResultSet generatedKeys = ps.getGeneratedKeys()) {
                if (generatedKeys.next()) {
                    partie.setId(generatedKeys.getLong(1));
                }
            }

        } catch (SQLException e) {
            throw new DBexception("Erreur lors de l'enregistrement de la partie", e);
        }
    }

    public List<Partie> listerToutesLesParties() {
        List<Partie> parties = new ArrayList<>();
      
        String sql = """
            SELECT 
                p.id as partie_id, p.date,
                j1.id as j1_id, j1.username as j1_username,
                j2.id as j2_id, j2.username as j2_username,
                g.id as gagnant_id, g.username as gagnant_username
            FROM PARTIE p
            JOIN JOUEUR j1 ON p.joueur1Id = j1.id
            JOIN JOUEUR j2 ON p.joueur2Id = j2.id
            LEFT JOIN JOUEUR g ON p.gagnantId = g.id
            ORDER BY p.date DESC
        """;

        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {

            while (rs.next()) {
                
                Joueur joueur1 = new Joueur(rs.getLong("j1_id"), rs.getString("j1_username"));
                Joueur joueur2 = new Joueur(rs.getLong("j2_id"), rs.getString("j2_username"));

                Joueur gagnant = null;
                long gagnantId = rs.getLong("gagnant_id");
                if (!rs.wasNull()) { 
                    gagnant = new Joueur(gagnantId, rs.getString("gagnant_username"));
                }
                
                Partie partie = new Partie(
                    rs.getLong("partie_id"),
                    joueur1,
                    joueur2,
                    gagnant,
                    rs.getTimestamp("date").toLocalDateTime()
                );
                parties.add(partie);
            }
        } catch (SQLException e) {
            throw new DBexception("Erreur lors de la récupération des parties", e);
        }

        return parties;
    }

  
    public List<Partie> listerPartiesParJoueur(Long joueurId) {
        List<Partie> parties = new ArrayList<>();
        String sql = """
            SELECT 
                p.id as partie_id, p.date,
                j1.id as j1_id, j1.username as j1_username,
                j2.id as j2_id, j2.username as j2_username,
                g.id as gagnant_id, g.username as gagnant_username
            FROM PARTIE p
            JOIN JOUEUR j1 ON p.joueur1Id = j1.id
            JOIN JOUEUR j2 ON p.joueur2Id = j2.id
            LEFT JOIN JOUEUR g ON p.gagnantId = g.id
            WHERE p.joueur1Id = ? OR p.joueur2Id = ?
            ORDER BY p.date DESC
        """;

        try (Connection con = DBUtils.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setLong(1, joueurId);
            ps.setLong(2, joueurId);
            
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    Joueur joueur1 = new Joueur(rs.getLong("j1_id"), rs.getString("j1_username"));
                    Joueur joueur2 = new Joueur(rs.getLong("j2_id"), rs.getString("j2_username"));
                    Joueur gagnant = null;
                    long gagnantId = rs.getLong("gagnant_id");
                    if (!rs.wasNull()) {
                        gagnant = new Joueur(gagnantId, rs.getString("gagnant_username"));
                    }
                    
                    Partie partie = new Partie(
                        rs.getLong("partie_id"),
                        joueur1,
                        joueur2,
                        gagnant,
                        rs.getTimestamp("date").toLocalDateTime()
                    );
                    parties.add(partie);
                }
            }
        } catch (SQLException e) {
            throw new DBexception("Erreur lors de la récupération des parties par joueur", e);
        }
        return parties;
    }
    
 
}