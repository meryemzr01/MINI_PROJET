package mini_projet.dal;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;


public class dbinstaller {

    // Vérifie si la base est déjà installée 
    
    public static boolean checkIfDbExist() {
        try {
            Connection connection = DBUtils.getConnection();

            String checkTableSQL = """
                SELECT COUNT(*) AS tableCount
                FROM INFORMATION_SCHEMA.TABLES
                WHERE TABLE_NAME = 'JOUEUR'
            """;

            try (Statement statement = connection.createStatement();
                 ResultSet resultSet = statement.executeQuery(checkTableSQL)) {

                return resultSet.next() && resultSet.getInt("tableCount") == 1;
            }

        } catch (Exception ex) {
            throw new DBexception("Erreur lors de la vérification de la base de données", ex);
        }
    }

    // Installe la base de données : crée les tables JOUEUR et PARTIE
   
    public static boolean install() {
        try {
            Connection connection = DBUtils.getConnection();
            Statement statement = connection.createStatement();

            String createTableJoueur = """
                CREATE TABLE IF NOT EXISTS JOUEUR (
                    id BIGINT PRIMARY KEY AUTO_INCREMENT,
                    username VARCHAR(100) NOT NULL UNIQUE,
                    password VARCHAR(100) NOT NULL,
                    email VARCHAR(100)
                );
            """;

            String createTablePartie = """
                CREATE TABLE IF NOT EXISTS PARTIE (
                    id BIGINT PRIMARY KEY AUTO_INCREMENT,
                    date TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                    joueur1Id BIGINT NOT NULL,
                    joueur2Id BIGINT NOT NULL,
                    gagnantId BIGINT,
                    FOREIGN KEY (joueur1Id) REFERENCES JOUEUR(id),
                    FOREIGN KEY (joueur2Id) REFERENCES JOUEUR(id),
                    FOREIGN KEY (gagnantId) REFERENCES JOUEUR(id)
                );
            """;

            statement.execute(createTableJoueur);
            statement.execute(createTablePartie);

            return true;

        } catch (Exception ex) {
            throw new DBexception("Erreur lors de l'installation de la base de données", ex);
        }
    }
}
