package mini_projet.gui;

import mini_projet.bll.GameManager;
import mini_projet.bo.CelluleType;
import mini_projet.bo.Joueur;
import mini_projet.dal.dbinstaller;
import mini_projet.dal.JoueurDAO;
import mini_projet.dal.PartieDAO;
import mini_projet.bo.Partie;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Scanner;

public class Main {
    private static final JoueurDAO joueurDAO = new JoueurDAO();
    private static final PartieDAO partieDAO = new PartieDAO();
    private static final Scanner scanner = new Scanner(System.in);

    public static void main(String[] args) {
        // Vérifier installation de la  bdd
        if (!dbinstaller.checkIfDbExist()) {
            System.out.println("Installation de la base de données...");
            dbinstaller.install();
            System.out.println("----Base installée----");
        }

        while (true) {
            System.out.println("\n----- Menu Principal -----");
            System.out.println("1. Créer un joueur");
            System.out.println("2. Se connecter");
            System.out.println("3. Afficher les parties");
            System.out.println("0. Quitter");
            System.out.print("Choix : ");
            int choix = Integer.parseInt(scanner.nextLine());

            switch (choix) {
                case 1 -> creerJoueur();
                case 2 -> seConnecterEtJouer();
                case 3 -> afficherParties();
                case 0 -> {
                    System.out.println("---À bientôt!---");
                    System.exit(0);
                }
                default -> System.out.println("***Choix invalide***");
            }
        }
    }

    private static void creerJoueur() {
        System.out.print("Nom d'utilisateur : ");
        String username = scanner.nextLine();
        System.out.print("Mot de passe : ");
        String password = scanner.nextLine();
        System.out.print("Email : ");
        String email = scanner.nextLine();

        Joueur j = new Joueur(null, username, password, email);
        joueurDAO.ajouterJoueur(j);
        System.out.println("--- Joueur ajouté !---");
    }

    private static void seConnecterEtJouer() {
        System.out.print("Nom du joueur 1 : ");
        Joueur j1 = authentifier(scanner.nextLine());
        if (j1 == null) return;

        System.out.print("Nom du joueur 2 : ");
        Joueur j2 = authentifier(scanner.nextLine());
        if (j2 == null) return;

        System.out.println("---- Début de la partie ----");
        GameManager gm = new GameManager(j1, j2);

        boolean partieTerminee = false;
        while (!partieTerminee) {
        	  gm.afficherPlateau(); //  Affiche l’échiquier à chaque tour
           

            //  Afficher seulement les animaux du joueur courant
            System.out.println("Animaux disponibles pour " + gm.getJoueurActuel().getUsername() + " :");
            gm.getPieces().stream()
                .filter(a -> a.getProprietaire().equals(gm.getJoueurActuel()))
                .forEach(a -> System.out.println(" - " + a.getNom() + " (" + a.getX() + "," + a.getY() + ")"));

            System.out.print("Nom de l'animal à déplacer : ");
            String nomAnimal = scanner.nextLine().trim();

            // Recherche de l’animal
            var animal = gm.getPieces().stream()
                .filter(a -> a.getNom().equalsIgnoreCase(nomAnimal)
                        && a.getProprietaire().equals(gm.getJoueurActuel()))
                .findFirst()
                .orElse(null);

            if (animal == null) {
                System.out.println(" *** Animal introuvable ***");
                continue;
            }

            // Saisie position
            System.out.print("Nouvelle position X : ");
            int x = Integer.parseInt(scanner.nextLine());
            System.out.print("Nouvelle position Y : ");
            int y = Integer.parseInt(scanner.nextLine());

            boolean resultat = gm.deplacerAnimal(animal, x, y);

            // Vérification victoire
            if (resultat && gm.getEchiquier().getCellule(x, y).getType() == CelluleType.TERRIER) {
                partieTerminee = true;

                Partie partie = new Partie(null, j1, j2, gm.getJoueurActuel(), LocalDateTime.now());
                partieDAO.ajouterPartie(partie);
                System.out.println("---- Partie enregistrée !----");
                System.out.println("--- Victoire de : " + gm.getJoueurActuel().getUsername());
            }
        }
    }

    private static Joueur authentifier(String username) {
        System.out.print("Mot de passe : ");
        String password = scanner.nextLine();
        Joueur joueur = joueurDAO.authentifier(username, password);
        if (joueur == null) {
            System.out.println("*** Authentification échouée ***");
        }
        return joueur;
    }

    private static void afficherParties() {
        List<Partie> parties = partieDAO.listerToutesLesParties();
        if (parties.isEmpty()) {
            System.out.println("--- Aucune partie enregistrée ---");
            return;
        }

        for (Partie p : parties) {
            System.out.println(p);
        }
    }
}
